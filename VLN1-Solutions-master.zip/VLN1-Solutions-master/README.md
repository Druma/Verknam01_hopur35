# VLN1-Solutions
Solutions for the course VLN1 at Reykjavik University
