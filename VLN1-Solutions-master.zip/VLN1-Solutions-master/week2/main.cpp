#include "consoleui.h"

int main()
{
    ConsoleUI ui;

    return ui.start();
}

